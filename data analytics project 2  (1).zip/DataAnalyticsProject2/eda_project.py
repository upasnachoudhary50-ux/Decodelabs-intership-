import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("train.csv")

print(df.head())

print(df.info())

print(df.isnull().sum())

print(df.describe())

print(df.mean(numeric_only=True))

print(df.median(numeric_only=True))

print(df.corr(numeric_only=True))

df.hist(figsize=(10, 8))
plt.show()

df.plot(kind="box", figsize=(10, 6))
plt.show()